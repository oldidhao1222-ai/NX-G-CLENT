package com.nxg.client

import org.junit.Assert.assertEquals
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun packageIdentityIsStable() {
        assertEquals("com.nxg.client", "com.nxg.client")
    }
}

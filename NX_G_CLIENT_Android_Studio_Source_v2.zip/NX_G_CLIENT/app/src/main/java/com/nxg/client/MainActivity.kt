package com.nxg.client

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Extension
import androidx.compose.material.icons.outlined.Gamepad
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import org.json.JSONObject
import java.io.BufferedInputStream
import java.util.zip.ZipInputStream

private val NxBlack = Color(0xFF080808)
private val NxSurface = Color(0xFF151515)
private val NxWhite = Color(0xFFF5F5F5)
private val NxMuted = Color(0xFFB8B8B8)

data class PackRecord(
    val name: String,
    val fileName: String,
    val uri: Uri,
    val status: String,
    val packType: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NxClientApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NxClientApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("nxg_settings", Context.MODE_PRIVATE) }
    var reduceMotion by remember { mutableStateOf(prefs.getBoolean("reduce_motion", false)) }
    var showAbout by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    val packs = remember { mutableStateListOf<PackRecord>() }

    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) {
                // Some document providers do not grant persistable permissions.
            }
            val fileName = displayName(context, uri) ?: "Selected pack"
            val ext = fileName.substringAfterLast('.', "").lowercase()
            if (ext !in setOf("mcpack", "mcaddon", "zip")) {
                message = "Unsupported file type. Choose a .mcpack, .mcaddon, or ZIP pack."
            } else {
                val validation = validatePack(context, uri, ext)
                packs.removeAll { it.uri == uri }
                packs.add(0, PackRecord(
                    name = validation.first ?: fileName.substringBeforeLast('.'),
                    fileName = fileName,
                    uri = uri,
                    status = validation.second,
                    packType = ext.uppercase()
                ))
                message = validation.second
            }
        }
    }

    MaterialTheme(
        colorScheme = androidx.compose.material3.darkColorScheme(
            primary = NxWhite,
            onPrimary = NxBlack,
            background = NxBlack,
            onBackground = NxWhite,
            surface = NxSurface,
            onSurface = NxWhite,
            secondary = NxMuted
        )
    ) {
        Scaffold(
            containerColor = NxBlack,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("NX G CLIENT", fontWeight = FontWeight.Black)
                            Text("BEDROCK COMPANION • ANDROID", style = MaterialTheme.typography.labelSmall, color = NxMuted)
                        }
                    },
                    actions = {
                        TextButton(onClick = { showAbout = true }) {
                            androidx.compose.material3.Icon(Icons.Outlined.Info, contentDescription = "About", tint = NxWhite)
                        }
                    }
                )
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item { Spacer(Modifier.height(4.dp)) }
                item { HeaderCard() }
                item {
                    SectionCard(title = "Minecraft status", icon = {
                        androidx.compose.material3.Icon(Icons.Outlined.Gamepad, contentDescription = null)
                    }) {
                        val installed = isMinecraftInstalled(context)
                        Text(
                            if (installed) "Minecraft Bedrock appears to be installed."
                            else "Minecraft Bedrock was not detected.",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "Android does not expose a reliable game-version API to companion apps. Confirm the version inside Minecraft.",
                            color = NxMuted, style = MaterialTheme.typography.bodySmall
                        )
                        Spacer(Modifier.height(12.dp))
                        Button(
                            onClick = {
                                val intent = context.packageManager.getLaunchIntentForPackage("com.mojang.minecraftpe")
                                if (intent != null) {
                                    try { context.startActivity(intent) }
                                    catch (_: ActivityNotFoundException) { message = "Could not open Minecraft." }
                                } else message = "Minecraft Bedrock is not installed or cannot be launched."
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Open Minecraft") }
                    }
                }
                item {
                    SectionCard(title = "Pack manager", icon = {
                        androidx.compose.material3.Icon(Icons.Outlined.Extension, contentDescription = null)
                    }) {
                        Text("Import and validate supported pack files. Importing here does not automatically enable a pack in a world.", color = NxMuted, style = MaterialTheme.typography.bodySmall)
                        Spacer(Modifier.height(12.dp))
                        Button(
                            onClick = { picker.launch(arrayOf("*/*")) },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Select .mcpack / .mcaddon") }
                        Spacer(Modifier.height(6.dp))
                        OutlinedButton(
                            onClick = { message = "After validation, use Share to Minecraft if offered by Android, or open the pack from your file manager. Minecraft's import behavior depends on your installed version." },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("How to import into Minecraft") }
                    }
                }
                if (packs.isNotEmpty()) {
                    item { Text("RECENTLY CHECKED PACKS", style = MaterialTheme.typography.labelLarge, color = NxMuted) }
                    items(packs, key = { it.uri.toString() }) { pack ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = NxSurface),
                            border = BorderStroke(1.dp, Color(0xFF333333)),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Column(Modifier.fillMaxWidth().padding(14.dp)) {
                                Text(pack.name, fontWeight = FontWeight.SemiBold)
                                Text("${pack.fileName} • ${pack.packType}", color = NxMuted, style = MaterialTheme.typography.bodySmall)
                                Spacer(Modifier.height(6.dp))
                                Text(pack.status, style = MaterialTheme.typography.bodySmall)
                                Spacer(Modifier.height(10.dp))
                                OutlinedButton(
                                    onClick = { sharePackToMinecraft(context, pack.uri, pack.fileName) },
                                    modifier = Modifier.fillMaxWidth()
                                ) { Text("Share / open with compatible app") }
                            }
                        }
                    }
                }
                item {
                    SectionCard(title = "Preferences", icon = {
                        androidx.compose.material3.Icon(Icons.Outlined.Settings, contentDescription = null)
                    }) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.weight(1f)) {
                                Text("Reduce motion")
                                Text("Keeps transitions minimal.", color = NxMuted, style = MaterialTheme.typography.bodySmall)
                            }
                            Switch(checked = reduceMotion, onCheckedChange = {
                                reduceMotion = it
                                prefs.edit().putBoolean("reduce_motion", it).apply()
                            })
                        }
                    }
                }
                item {
                    Text("NX G CLIENT is a companion app, not a replacement game client. Features are limited to supported Android and Bedrock workflows.", color = NxMuted, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(vertical = 8.dp))
                }
            }
        }
    }

    if (showAbout) {
        AlertDialog(
            onDismissRequest = { showAbout = false },
            title = { Text("NX G CLIENT") },
            text = { Text("Version 1.0.0\nA black-and-white Minecraft Bedrock companion for Android.\n\nThis app is not affiliated with or endorsed by Mojang or Microsoft.") },
            confirmButton = { TextButton(onClick = { showAbout = false }) { Text("Close") }
            }
        )
    }
    if (message != null) {
        AlertDialog(
            onDismissRequest = { message = null },
            title = { Text("NX G CLIENT") },
            text = { Text(message ?: "") },
            confirmButton = { TextButton(onClick = { message = null }) { Text("OK") } }
        )
    }
}

@Composable
private fun HeaderCard() {
    Card(
        colors = CardDefaults.cardColors(containerColor = NxWhite),
        shape = RoundedCornerShape(20.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(18.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Surface(color = NxBlack, shape = RoundedCornerShape(12.dp)) {
                Text("NX", modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp), color = NxWhite, fontWeight = FontWeight.Black, style = MaterialTheme.typography.headlineMedium)
            }
            Column {
                Text("PLAY YOUR WAY.", color = NxBlack, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleLarge)
                Text("A clean hub for Bedrock packs.", color = Color(0xFF333333), style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

@Composable
private fun SectionCard(
    title: String,
    icon: @Composable () -> Unit,
    content: @Composable () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = NxSurface),
        border = BorderStroke(1.dp, Color(0xFF303030)),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(Modifier.fillMaxWidth().padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                icon()
                Text(title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            }
            Spacer(Modifier.height(12.dp))
            content()
        }
    }
}

private fun isMinecraftInstalled(context: Context): Boolean =
    try {
        context.packageManager.getApplicationInfo("com.mojang.minecraftpe", 0)
        true
    } catch (_: Exception) {
        false
    }

private fun displayName(context: Context, uri: Uri): String? =
    context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
        if (cursor.moveToFirst()) cursor.getString(0) else null
    }

private fun validatePack(context: Context, uri: Uri, extension: String): Pair<String?, String> {
    return try {
        context.contentResolver.openInputStream(uri).use { stream ->
            if (stream == null) return null to "Could not read this file."
            val zip = ZipInputStream(BufferedInputStream(stream))
            var foundManifest = false
            var displayName: String? = null
            var checkedEntries = 0
            var entry = zip.nextEntry
            while (entry != null && checkedEntries < 5000) {
                checkedEntries++
                if (!entry.isDirectory && entry.name.substringAfterLast('/') == "manifest.json") {
                    val bytes = zip.readBytes()
                    val json = JSONObject(String(bytes, Charsets.UTF_8))
                    val header = json.optJSONObject("header")
                    displayName = header?.optString("name")?.takeIf { it.isNotBlank() && it != "null" }
                    foundManifest = true
                    break
                }
                zip.closeEntry()
                entry = zip.nextEntry
            }
            zip.close()
            when {
                foundManifest -> displayName to "Manifest found. Basic archive check passed; test the pack in Minecraft before relying on it."
                extension == "mcaddon" -> null to "No manifest found in the scanned archive. Some add-on bundles contain nested packs; inspect in Minecraft or select the contained .mcpack files."
                else -> null to "No manifest.json found in the archive. This may not be a valid Bedrock pack."
            }
        }
    } catch (e: Exception) {
        null to "Could not validate this archive: ${e.message ?: "unknown file error"}"
    }
}

private fun sharePackToMinecraft(context: Context, uri: Uri, fileName: String) {
    val mime = when (fileName.substringAfterLast('.', "").lowercase()) {
        "mcpack" -> "application/octet-stream"
        "mcaddon" -> "application/octet-stream"
        else -> "*/*"
    }
    val sendIntent = Intent(Intent.ACTION_SEND).apply {
        type = mime
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    try {
        context.startActivity(Intent.createChooser(sendIntent, "Open pack with"))
    } catch (_: ActivityNotFoundException) {
        android.widget.Toast.makeText(context, "No compatible app was found to receive this pack.", android.widget.Toast.LENGTH_LONG).show()
    }
}
